> # Update Information (Latest listed first)
> ### 1.0.7
> - Update for Valheim 0.217.22
> ### 1.0.6
> - Update for Valheim 0.216.9
> ### 1.0.5
> - Revert the cooldown change. It was causing issues with the mod. I will look into it more in the future.
> ### 1.0.4
> - Update to use a cooldown in minutes. This will prevent spamming the sleep request.
> - Add localization support.
> ### 1.0.3
> - Update ServerSync internally
> ### 1.0.2
> - Update ServerSync internally
> ### 1.0.1
> - Update ServerSync internally
> ### v1.0.0
> - Initial Release
